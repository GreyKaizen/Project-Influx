#ifndef FUNCTION_H
#define FUNCTION_H

// #include "Buyer.h"
// #include "Admin.h"
// #include "Inventory.h"
// #include "Product.h"
#include <vector>
#include <iostream>
#include <sstream>
#include <string>

// #include "Order.h"
// #include "Payment.h"
// #include "Invoice.h"
// #include "Product.h"

using namespace std;

vector<string> split( string& str, char delimiter);

#endif