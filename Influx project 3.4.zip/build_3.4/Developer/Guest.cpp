#include <iostream>
#include  "Guest.h"
#include "Session.h"

using namespace std;

void Guest::register_user(){
    // Session session;
    // session.Register();
}

void Guest::print_Register_toBuy() const {
    cout << "Khareedar banen" << endl << "Paison ki Bachat kren" << endl << "Coupons aur Gift Cards Pain" << endl << "Aur buhut si sahultin pain " << endl << endl << "Abhi apni shanakht Krwain,Influx ko Yaqeeni banain" << "Badlein Khayalat, Badlein Zindagi"<<endl<<"Aapka Sapna, Hamari Zimmedari"<<endl<<"Aapki Soch, Hamari Shakti"<<endl<<"Aapki Khwahish, Hamari Zimmedari"<< endl;
}

string Guest::check_Person() const {
    //Empty IMplementation
}
void Guest::print_info() const {
    //Empty IMplemen
}
void Guest::editINFO() {
    //Empty IMplemen
}

